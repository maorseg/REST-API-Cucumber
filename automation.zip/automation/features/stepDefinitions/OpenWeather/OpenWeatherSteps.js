/* API requests using axios

1) https://www.youtube.com/watch?v=6LyagkoRWYA
2) https://github.com/axios/axios
3) https://axios-http.com/
4) https://github.com/Sam56/Api-testing-using-axios-and-cucumber/blob/master/features/api.feature

openweathermap steps  
appid = 17b7e1cec99e6068f56ff1c4894dcf22
API doc References - https://openweathermap.org/stations 

*/

const { Given, When, Then } = require("cucumber");
const { expect } = require('chai');  // Using Expect style
const chai = require('chai');
const assertArrays = require('chai-arrays');
chai.use(assertArrays);
const axios = require("axios").default;
let post_response, get_response, delete_response, put_response;
let headers = {};

// You can specify Config Defaults that will be applied to every request
axios.defaults.baseURL = "http://api.openweathermap.org/data/3.0/";
axios.defaults.timeout === 10000;
axios.defaults.headers.get['Content-Type'] = 'application/json';
axios.defaults.headers.post['Content-Type'] = 'application/json';
axios.defaults.headers.patch['Content-Type'] = 'application/json';
axios.defaults.headers.put['Content-Type'] = 'application/json';
axios.defaults.headers.delete['Content-Type'] = 'application/json';


///////////
// When //
//////////

When(/^send POST request to "([^"]*)", with data$/, async (url, docString) => {

  post_response = await axios
    .post(url, JSON.parse(docString), { headers: headers })
    .then(function (response) {
    // console.log(response);
    // console.log(JSON.stringify(response));
      return response;
    })
    .catch(function (response) {
      return response.response;
    });
});

When(/^send PUT request to "([^"]*)", with data$/, async (url, docString) => {

  put_response = await axios
    .put(url, JSON.parse(docString), { headers: headers })
    .then(function (response) {
     // console.log(response);
     // console.log(JSON.stringify(response));
      return response;
    })
    .catch(function (response) {
      return response.response;
    });
});

When(/^send PATCH request to "([^"]*)", with data$/, async (url, docString) => {
 
  put_response = await axios
    .patch(url, JSON.parse(docString), { headers: headers })
    .then(function (response) {
  // console.log(response);
  // console.log(JSON.stringify(response));
      return response;
    })
    .catch(function (response) {
      return response.response;
    });
});

When(/^retrieve GET request to "([^"]*)"/, async (url) => {

  get_response = await axios
    .get(url, { headers: headers })
    .then(function (response) {
      // console.log(response.data);
      // console.log('\n')
      // console.log("response body:");
      // console.log(JSON.stringify(response.data));
      // console.log('\n')
      return response;
    })
    .catch(function (response) {
      return response.response;
    });
});

When(/^send Delete request to "([^"]*)"/, async (url) => {

  get_response = await axios
    .delete(url, { headers: headers })
    .then(function (response) {
     // console.log(response.data);
    //  console.log(JSON.stringify(response.data));
      return response;
    })
    .catch(function (response) {
      return response.response;
    });
});

When(/^delete request to "([^"]*)"/, async (url) => {
  let headers = {
    Authorization:
      "Bearer 930d5daf02ac702b4ca6e402d622eeccdb5e10b47a83c8882191f0865c9eda80",
  };
  delete_response = await axios
    .delete(url, { headers: headers })
    .then(function (response) {
    //  console.log(response);
      return response;
    })
    .catch(function (response) {
      return response.response;
    });
});

When(
  "Get the stations created and the delete status should be {int}",
  async (status) => {
    {
      let url = `http://api.openweathermap.org/data/3.0/stations/6025be7609e7430001b9db81?appid=8659182afb89bad558b38fde3c4c5797`;

      delete_response = await axios
        .delete(url, { headers: headers })
        .then(function (response) {
        //  console.log(response.data);
          return response;
        })
        .catch(function (response) {
          return response.response;
        });
      expect(await delete_response.status).equal(status);
    }
  }
);

When(
  "Get not existing station the get status should be {int} and the body should have {string}",
  async (status, message) => {
    {
      let url = `http://api.openweathermap.org/data/3.0/stations/6025be7609e7430001b9db81?appid=17b7e1cec99e6068f56ff1c4894dcf22`;

      get_response = await axios
        .get(url, { headers: headers })
        .then(function (response) {
        //  console.log(response.data);
          return response;
        })
        .catch(function (response) {
          return response.response;
        });
      expect(await get_response.status).equal(status);
      expect(await get_response.data.message).equal(message);
    }
  }
);

///////////
// Then //
//////////

Then("the post status should be {int}", async (status) => {
  expect(await post_response.status).equal(status);
});

Then("the put status should be {int}", async (status) => {
  expect(await put_response.status).equal(status);
});

Then("the post status body should have {string}", async (message) => {
  expect(await post_response.data.message).equal(message);
});

Then("the post status text should have {string}", async (message) => {
  expect(await post_response.statusText).equal(message);
});

Then("the put status text should have {string}", async (message) => {
  expect(await put_response.statusText).equal(message);
});

Then("the post response body should be with data", () => { 
  expect([post_response.data]).to.be.an("array").that.is.not.empty;
});

Then("the get status body should have {string}", async (message) => {
  expect(await get_response.data.message).equal(message);
});

Then("the get status should be {int}", async (status) => {
  expect(await get_response.status).equal(status);
});

Then("the get response should be with data", async () => {
 expect([await get_response.data]).to.be.array();
 expect([await get_response.data]).to.be.ofSize(1);
 expect([await get_response.data]).to.be.an("array").that.is.not.empty;
 
});

Then("the get response should be with header", async () => {
  expect([await get_response.data]).to.be.array();
  expect([await get_response.data]).to.be.ofSize(1);
  expect([await get_response.data]).to.be.an("array").that.is.not.empty;
  
 });

Then("the get response should be without data", async () => {
  expect([await get_response.data]).to.be.an("array").that.is.empty;
});

Then(/^the get response header should be of type "([^"]*)?"/, async (element) => {
 // console.log(get_response.headers['content-type']);
  expect(await get_response.headers['content-type']).contain(element);
});

Then(/^the get response body for geocoding should contain "([^"]*)?"/, async (element) => {
 // console.log (get_response.data);
  expect(await get_response.data[0].name).contain(element);
});

Then(/^the get response body for current solar radiation data should contain "([^"]*)?"/, async (element) => {
 //  console.log (get_response.data{0});
   expect(await JSON.stringify(response.data)).contain(element);
 });

Then(/^the get response body should contain station id "([^"]*)?"/, async (element) => {
  // console.log (get_response.data);
   expect(await get_response.data.id).contain(element);
 });

 Then(/^the get response body should contain station name "([^"]*)?"/, async (element) => {
  // console.log (get_response.data);
   expect(await get_response.data.name).contain(element);
 });

 Then(/^the get response body should contain geographical coordinates "([^"]*)?"/, async (element) => {
  // console.log (get_response.data);
   expect(await get_response.data.coord).contain(element);
 });

 Then(/^the get response body for city should contain "([^"]*)?"/, async (element) => {
  // console.log (get_response.data);
   expect(await get_response.data.name).contain(element);
 });

 Then(/^the post response header should be of type "([^"]*)?"/, async (element) => {
  // console.log(get_response.headers['content-type']);
   expect(await post_response.headers['content-type']).contain(element);
 });

Then(/^the post response body for road risk should contain "([^"]*)?"/, async (element) => {
 //  console.log (post_response.data[0]);
  expect(await post_response.data[0].coord).to.not.have.any.keys(element);
 });
 