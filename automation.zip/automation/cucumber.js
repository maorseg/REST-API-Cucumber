module.exports = {
  default: `--format-options '{"snippetInterface": "synchronous"}' -f ./report-portal-formatter.js`,
};